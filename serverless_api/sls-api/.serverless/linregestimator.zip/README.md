## Deploying regression model using Flask
This flask API uses a pretrained linear regression model 
to predict the value of used mid-size sedans. Html template 
and css taken from [here](https://github.com/MaajidKhan/DeployMLModel-Flask
)