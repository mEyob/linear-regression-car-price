import serverless_sdk
sdk = serverless_sdk.SDK(
    tenant_id='meyob',
    application_name='linregapp',
    app_uid='vdG0xkj2n6yDgjbKd0',
    tenant_uid='xrvqLDLzx4hQwL5TBl',
    deployment_uid='abb0c654-cc05-44c8-a66d-7ad8ec163ed7',
    service_name='linregestimator',
    stage_name='dev',
    plugin_version='3.2.4'
)
handler_wrapper_kwargs = {'function_name': 'linregestimator-dev-app', 'timeout': 6}
try:
    user_handler = serverless_sdk.get_user_handler('wsgi_handler.handler')
    handler = sdk.handler(user_handler, **handler_wrapper_kwargs)
except Exception as error:
    e = error
    def error_handler(event, context):
        raise e
    handler = sdk.handler(error_handler, **handler_wrapper_kwargs)
